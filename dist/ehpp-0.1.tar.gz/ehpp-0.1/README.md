EHPP is a preprocessor for [EspHome](https://esphomelib.com/esphomeyaml/) that simplifies the management of configuration files when you have multiple devices.

(more to come...)